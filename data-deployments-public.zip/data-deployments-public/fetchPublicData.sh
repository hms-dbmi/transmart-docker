wget -N https://s3.amazonaws.com/publicstudies/GSE13168/Asthma_Misior_GSE13168.txt.gz -P ./data/public_studies/GSE13168/clinical/
wget -N https://s3.amazonaws.com/publicstudies/GSE13168/Asthma_Misior_GSE13168_gene_expression_data_L.txt.gz -P ./data/public_studies/GSE13168/gex/
wget -N https://s3.amazonaws.com/publicstudies/GSE20194/Breast_Cancer_Popovici_GSE20194.txt.gz -P ./data/public_studies/GSE20194/clinical/
wget -N https://s3.amazonaws.com/publicstudies/GSE31773/gse31773.txt.gz -P ./data/public_studies/GSE31773/clinical/

gzip -df data/public_studies/GSE13168/clinical/Asthma_Misior_GSE13168.txt.gz 
gzip -df data/public_studies/GSE13168/gex/Asthma_Misior_GSE13168_gene_expression_data_L.txt.gz
gzip -df data/public_studies/GSE20194/clinical/Breast_Cancer_Popovici_GSE20194.txt.gz
gzip -df data/public_studies/GSE31773/clinical/gse31773.txt.gz
