wget -N https://s3.amazonaws.com/publicstudies/GSE13168/DE_MRNA_ANNOTATION.dsv.gz -P ./data/meta-data/
wget -N https://s3.amazonaws.com/publicstudies/GSE13168/PROBESET_DEAPP.dsv.gz -P ./data/meta-data/
wget -N https://s3.amazonaws.com/publicstudies/GSE13168/DE_GPL_INFO.dsv -P ./data/meta-data/
wget -N https://s3.amazonaws.com/publicstudies/GSE13168/SEARCH_KEYWORD_TERM.dsv.gz -P ./data/meta-data/
wget -N https://s3.amazonaws.com/publicstudies/GSE13168/SEARCH_KEYWORD.dsv.gz -P ./data/meta-data/

gzip -dfk data/meta-data/DE_MRNA_ANNOTATION.dsv.gz
gzip -dfk data/meta-data/PROBESET_DEAPP.dsv.gz
gzip -dfk data/meta-data/SEARCH_KEYWORD_TERM.dsv.gz
gzip -dfk data/meta-data/SEARCH_KEYWORD.dsv.gz
