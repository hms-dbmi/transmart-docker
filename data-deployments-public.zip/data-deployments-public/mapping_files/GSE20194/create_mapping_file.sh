create_column_mapping_from_directory.pl "/data-deployments/data/public_studies/GSE20194/clinical/" "\\Public Studies\\GSE20194\\"
