#!/usr/bin/perl

use Scalar::Util qw(looks_like_number);
use Data::Dumper;

my $dataFileLocation = $ARGV[0];

my %fieldTypeHash = ();

open my $dataFile, '<' , $dataFileLocation || die "Can't open data file: $!\n";
open my $outputDataTypeFile, '>' , "dataTypes.map.type" || die "Can't open file: $!\n";;

my $rowCount = 0;
my $breakLoop = false;

my $dataHeader = <$dataFile>;
		
chomp($dataHeader);

my @headerArray = split(/\t/,$dataHeader);

$filesAndHeaderCount{$f} = \@headerArray;
		
while (<$dataFile>)
{
	my $line = $_;

	chomp $line;

	my @fieldSplit = split(/\t/,$line);
	
	for my $i (0 .. $#fieldSplit)
	{
		my $fieldType = "T";
		
		if (looks_like_number($fieldSplit[$i]))
		{
			$fieldType = "N";
		}
		  
		if(exists $fieldTypeHash{$headerArray[$i]}) 
		{
			$fieldTypeHash{$headerArray[$i]} = $fieldTypeHash{$headerArray[$i]} . $fieldType;
		}
		else 
		{

			$fieldTypeHash{$headerArray[$i]} = $fieldType;
		}				  
	}
		
}

#Consolidate the column types.
while(my($k, $v) = each %fieldTypeHash) 		
{
	my $numericCount = ($v =~ tr/N//);

	if($numericCount > 10)
	{
		$finalFieldType = "N";
	}
	else
	{
		$finalFieldType = "T";					
	}
	
	my $trimmedHeader = $k;
	$trimmedHeader =~ s/^"(.*)"$/$1/;
	
	print $outputDataTypeFile "$trimmedHeader\t$finalFieldType\n";

}

close($dataFile);
close($outputDataTypeFile);
