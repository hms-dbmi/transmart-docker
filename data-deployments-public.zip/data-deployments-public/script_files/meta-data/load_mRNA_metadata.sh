/usr/bin/time -v sqlldr TM_CZ/TM_CZ@avl-dev-db.dbmi.hms.harvard.edu:1521/ORCL control=../../mapping_files/meta-data/DE_MRNA_ANNOTATIONS.ctl log=DE_MRNA_ANNOTATION.log
/usr/bin/time -v sqlldr TM_CZ/TM_CZ@avl-dev-db.dbmi.hms.harvard.edu:1521/ORCL control=../../mapping_files/meta-data/PROBESET_DEAPP.ctl log=PROBESET_DEAPP.log
