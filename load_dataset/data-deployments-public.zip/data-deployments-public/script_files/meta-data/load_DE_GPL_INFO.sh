/usr/bin/time -v sqlldr TM_CZ/TM_CZ@avl-dev-db.dbmi.hms.harvard.edu:1521/ORCL control=../../mapping_files/meta-data/DE_GPL_INFO.ctl log=DE_GPL_INFO.log
